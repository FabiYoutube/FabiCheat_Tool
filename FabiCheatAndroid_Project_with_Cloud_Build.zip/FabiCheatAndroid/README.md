# Fabi Cheat – Android Admin Edition

Dies ist ein Android-Studio-Projekt für eine lokale Admin-Command-Pad-App. Die Oberfläche kann Befehle in die Android-Zwischenablage kopieren und einen einfachen Dino-Befehl zusammenstellen.

## APK ohne PC über GitHub Actions bauen
1. Lade `FabiCheatAndroid_Project.zip` auf dein Android-Handy herunter und entpacke es.
2. Erstelle im Browser ein GitHub-Repository und lade die Dateien und Ordner aus dem entpackten Projekt hoch. Achte darauf, dass `.github/workflows/android.yml` mit hochgeladen wird.
3. Öffne im Repository den Tab **Actions** und wähle **Build Fabi Cheat APK**.
4. Tippe **Run workflow** und warte, bis der Lauf erfolgreich beendet ist.
5. Öffne den abgeschlossenen Lauf, gehe zu **Artifacts** und lade `Fabi-Cheat-debug-APK` herunter.
6. Entpacke dieses Artifact-ZIP; darin befindet sich `app-debug.apk`. Tippe die APK an, um sie zu installieren. Android kann nach Erlaubnis zum Installieren aus dieser Quelle fragen.

## APK bauen mit Android Studio
1. Öffne den Projektordner in Android Studio.
2. Lass Gradle synchronisieren und installiere Android SDK Platform 35 / Build Tools, falls gefragt.
3. Wähle **Build > Build APK(s)**.
4. Die Debug-APK liegt normalerweise unter `app/build/outputs/apk/debug/app-debug.apk`.

## Grenzen
- Das Projekt ist Quellcode, keine bereits kompilierte APK.
- Die App verbindet sich nicht mit ARK und injiziert keinen Code.
- ARK-Mobile-Befehle unterscheiden sich nach Edition/Version und können ununterstützt sein.
- Es gibt keine Netzwerkberechtigungen und keine Spielintegration.
